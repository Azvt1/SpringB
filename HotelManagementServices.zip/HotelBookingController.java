@RestController
@RequestMapping("/api/hotels")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    @PostMapping
    public ResponseEntity<Hotel> createHotel(@RequestBody Hotel hotel) {
        return new ResponseEntity<>(hotelService.createHotel(hotel), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Hotel> getHotelById(@PathVariable Long id) {
        return hotelService.getHotelById(id)
                .map(hotel -> new ResponseEntity<>(hotel, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping
    public List<Hotel> getAllHotels() {
        return hotelService.getAllHotels();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHotel(@PathVariable Long id) {
        hotelService.deleteHotel(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}


@RestController
@RequestMapping("/api/bookings/hotel")
public class HotelBookingController {

    @Autowired
    private HotelBookingService hotelBookingService;

    @PostMapping("/{hotelId}/{userId}")
    public ResponseEntity<HotelBooking> createBooking(@PathVariable Long hotelId, @PathVariable Long userId, @RequestBody BookingRequest bookingRequest) {
        HotelBooking booking = hotelBookingService.createBooking(hotelId, userId, bookingRequest.getCheckIn(), bookingRequest.getCheckOut());
        return new ResponseEntity<>(booking, HttpStatus.CREATED);
    }

    @GetMapping("/user/{userId}")
    public List<HotelBooking> getBookingsForUser(@PathVariable Long userId) {
        return hotelBookingService.getBookingsForUser(userId);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelBooking(@PathVariable Long id) {
        hotelBookingService.cancelBooking(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}


public class BookingRequest {
    private LocalDate checkIn;
    private LocalDate checkOut;
}
