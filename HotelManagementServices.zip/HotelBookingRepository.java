
@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {
}


@Repository
public interface HotelBookingRepository extends JpaRepository<HotelBooking, Long> {
    List<HotelBooking> findByUserId(Long userId);
}
